import sys, os
from PyQt5 import QtWidgets, QtCore, QtMultimedia, QtGui
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton
#основной блок, можно прослушивать и добавлять музыку

class AudioPlayer(QtWidgets.QWidget):
    def __init__(self, parent=None):
        super(AudioPlayer, self).__init__(parent, flags=QtCore.Qt.Window | QtCore.Qt.MSWindowsFixedSizeDialogHint)

        self.setWindowTitle("звук")

        self.mplPlayer = QtMultimedia.QMediaPlayer()
        self.mplPlayer.setVolume(50)
        self.mplPlayer.mediaStatusChanged.connect(self.init_player)
        self.mplPlayer.stateChanged.connect(self.set_player_state)

        self.playlist = QtMultimedia.QMediaPlaylist()

        self.list_widget = QtWidgets.QListWidget(self)
        self.list_widget.doubleClicked.connect(self.list_play_func)


#коллекция файлов
        files = ['удар.mp3', 'output.wav']
        for f in files:
            self.playlist.addMedia(QtMultimedia.QMediaContent(QtCore.QUrl.fromLocalFile(f)))
        self.playlist.setPlaybackMode(QtMultimedia.QMediaPlaylist.Loop)
        self.list_widget.addItems([m.split('/')[-1] for m in files])

        self.playlist.setCurrentIndex(0)
        self.mplPlayer.setPlaylist(self.playlist)

        button_next = QtWidgets.QPushButton("next")
        button_previous = QtWidgets.QPushButton("previous")

        h1layout = QtWidgets.QHBoxLayout()
        h1layout.addWidget(button_next)
        h1layout.addWidget(button_previous)

        button_next.clicked.connect(self.playlist.next)
        button_previous.clicked.connect(self.playlist.previous)
# добавление файлов
        vlayout = QtWidgets.QVBoxLayout()
        button_open = QtWidgets.QPushButton("New file")
        button_open.clicked.connect(self.open_file)
        vlayout.addWidget(button_open)
#ползунок
        self.sldPosition = QtWidgets.QSlider(QtCore.Qt.Horizontal)
        self.sldPosition.setMinimum(0)
        self.sldPosition.sliderMoved[int].connect(self.setPlayPosition)
        self.mplPlayer.positionChanged.connect(self.sldPosition.setValue)
        self.mplPlayer.durationChanged.connect(self.get_duration_func)
        self.sldPosition.setEnabled(False)

        vlayout.addWidget(self.sldPosition)
        hlayout = QtWidgets.QHBoxLayout()

        self.button_play = QtWidgets.QPushButton("▶")
        self.button_play.setFixedSize(70, 30)
        self.button_play.clicked.connect(self.mplPlayer.play)
        self.button_play.setEnabled(False)

        hlayout.addWidget(self.button_play)

        self.button_pause = QtWidgets.QPushButton("||")
        self.button_pause.setFixedSize(70, 30)
        self.button_pause.clicked.connect(self.mplPlayer.pause)
        self.button_pause.setEnabled(False)

        hlayout.addWidget(self.button_pause)

        self.button_stop = QtWidgets.QPushButton("stop")
        self.button_stop.setFixedSize(70, 30)
        self.button_stop.clicked.connect(self.mplPlayer.stop)


        hlayout.addWidget(self.button_stop)
        hlayout.setAlignment(QtCore.Qt.AlignLeft)

        vlayout.addLayout(hlayout)
        vlayout.addLayout(h1layout)

        hlayout = QtWidgets.QHBoxLayout()
        vlayout.addLayout(hlayout)
        self.label_current = QtWidgets.QLabel("библиотека")

        vlayout.addWidget(self.label_current)
        vlayout.addWidget(self.list_widget)

        self.playlist.currentMediaChanged.connect(self.show_File)

        self.setLayout(vlayout)
        self.resize(300, 100)

#функция которая открывает окно
    def show_File(self, content):
        self.label_current.setText(content.canonicalUrl().fileName())

# файлы в виджете...добавление
    def open_file(self):
        file, _ = QtWidgets.QFileDialog.getOpenFileName(self, "New Sound", "", "Sound Filed(*.mp3 *.wav)")
        if not file:
            return
        self.playlist.addMedia(QtMultimedia.QMediaContent(QtCore.QUrl.fromLocalFile(file)))
        self.list_widget.addItem(file.split('/')[-1])

    def init_player(self, state):
        if state == QtMultimedia.QMediaPlayer.LoadedMedia:
            self.mplPlayer.stop()
            self.button_play.setEnabled(True)
            self.sldPosition.setEnabled(True)
            self.sldPosition.setMaximum(self.mplPlayer.duration())

        elif state == QtMultimedia.QMediaPlayer.NoMedia or state == QtMultimedia.QMediaPlayer.InvalidMedia:
            self.sldPosition.setValue(0)
            self.sldPosition.setEnabled(False)
            self.button_play.setEnabled(False)
            self.button_stop.setEnabled(False)
            self.button_pause.setEnabled(False)

    def set_player_state(self, state):
        if state == QtMultimedia.QMediaPlayer.StoppedState:
            self.sldPosition.setValue(0)
            self.button_pause.setEnabled(False)
            self.button_stop.setEnabled(False)

        elif state == QtMultimedia.QMediaPlayer.PlayingState:
            self.button_pause.setEnabled(True)
            self.button_stop.setEnabled(True)

        elif state == QtMultimedia.QMediaPlayer.PausedState:
            self.button_pause.setEnabled(False)
            self.button_stop.setEnabled(True)

    def setPlayPosition(self, value):
         self.mplPlayer.setPosition(value)


#
    def list_play_func(self):
        self.mplPlayer.stop()
        self.playlist.setCurrentIndex(self.list_widget.currentRow())
        self.mplPlayer.play()

    def get_duration_func(self, d):
        self.sldPosition.setRange(0, d)
#основное окно
class MainWindow(QtWidgets.QWidget):
    def __init__(self):
        super().__init__()

        button_player = QtWidgets.QPushButton("тык")
        button_player.clicked.connect(self.open_player)

        hlayout = QtWidgets.QHBoxLayout(self)
        hlayout.addWidget(button_player)
#открывающееся окно
    def open_player(self):
        self.window = AudioPlayer(self)
        self.window.resize(400, 600)
        self.window.show()



if __name__ == '__main__':
    app = QtWidgets.QApplication(sys.argv)
    w = MainWindow()
    w.setWindowTitle("звук")
    w.show()
    sys.exit(app.exec_())