from window import Ui_MainWindow
import sys
from PyQt5.QtWidgets import QMainWindow
from PyQt5.QtMultimedia import QSound
from PyQt5.QtWidgets import QApplication, QWidget, QPushButton
import pyaudio
from PyQt5 import QtWidgets, QtCore, QtMultimedia
import wave
#здесь можно записывать музыку, разговоры, еще есть кнопки с ударами

class MyWidget(QMainWindow, Ui_MainWindow):
    def __init__(self):
        super().__init__()
        self.setupUi(self)
        self.sound = QSound('cccccc.wav', self)
        self.pushButton.clicked.connect(self.sound.play)
        self.sound2 = QSound('qqq.wav', self)
        self.pushButton_2.clicked.connect(self.sound2.play)
        self.sound3 = QSound('www.wav', self)
        self.pushButton_3.clicked.connect(self.sound3.play)
        self.sound4 = QSound('eee.wav', self)
        self.pushButton_4.clicked.connect(self.sound4.play)
        self.sound5 = QSound('rrr.wav', self)
        self.pushButton_6.clicked.connect(self.sound5.play)
        self.sound6 = QSound('ttt.wav', self)
        self.pushButton_7.clicked.connect(self.sound6.play)
        self.sound7 = QSound('yyy.wav', self)
        self.pushButton_8.clicked.connect(self.sound7.play)
        self.pushButton_5.clicked.connect(self.run)

    def open_file(self):
        file, _ = QtWidgets.QFileDialog.getOpenFileName(
                      self,
                      "Add Sound",
                      "",
                      "Sound Filed(*.mp3 *.ac3 *.wav)"
                    )
        if not file:                                                                        # !!!
            return
        self.playlist.addMedia(QtMultimedia.QMediaContent(QtCore.QUrl.fromLocalFile(file)))  # +
        self.list_widget.addItem(file.split('/')[-1])

    def run(self):
        CHUNK = 1024
        FORMAT = pyaudio.paInt16
        CHANNELS = 1 if sys.platform == 'darwin' else 2
        RATE = 44100
        RECORD_SECONDS = 8              #время записи

        with wave.open('output.wav', 'wb') as wf:
            p = pyaudio.PyAudio()
            wf.setnchannels(CHANNELS)
            wf.setsampwidth(p.get_sample_size(FORMAT))
            wf.setframerate(RATE)

            stream = p.open(format=FORMAT, channels=CHANNELS, rate=RATE, input=True, input_device_index=1)
            # в input_device_index надо написать номер микрофона(можно найти, запустив программу в папке "микрофоны.py"
            print('Recording...')
            for _ in range(0, RATE // CHUNK * RECORD_SECONDS):
                wf.writeframes(stream.read(CHUNK))
            print('Done')

            stream.close()
            p.terminate()



if __name__ == '__main__':
    app = QApplication(sys.argv)
    ex = MyWidget()
    ex.show()
    sys.exit(app.exec_())